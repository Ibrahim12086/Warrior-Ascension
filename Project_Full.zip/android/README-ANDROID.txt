This android/ module is a minimal native project that uses:
- NativeActivity
- CMake + Android NDK
- Assets taken from ../../Content

Build on GitHub Actions or locally with Gradle + Android SDK/NDK.
